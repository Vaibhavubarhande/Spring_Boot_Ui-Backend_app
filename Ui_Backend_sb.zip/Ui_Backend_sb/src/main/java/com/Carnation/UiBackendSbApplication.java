package com.Carnation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UiBackendSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(UiBackendSbApplication.class, args);
	}

}
