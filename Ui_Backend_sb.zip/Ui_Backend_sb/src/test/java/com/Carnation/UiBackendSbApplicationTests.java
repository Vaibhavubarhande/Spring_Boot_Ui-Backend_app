package com.Carnation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiBackendSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
